import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;

public class CollatzServer {

    // Константа размера пакета, как было в вашем коде
    private static final int BATCH_SIZE = 10_000;

    public static void main(String[] args) {
        int port = 9000;
        
        System.out.println("Server is starting on port " + port + "...");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                try {
                    // Ожидаем подключения клиента
                    Socket clientSocket = serverSocket.accept();
                    // Обрабатываем клиента в отдельном потоке, чтобы не блокировать сервер
                    new Thread(() -> handleClient(clientSocket)).start();
                } catch (IOException e) {
                    System.err.println("Connection error: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            // Читаем число N от клиента (до какого числа считать)
            String inputLine = in.readLine();
            if (inputLine == null) return;
            
            int N;
            try {
                N = Integer.parseInt(inputLine.trim());
            } catch (NumberFormatException e) {
                out.println("Error: Invalid number format");
                return;
            }

            System.out.println("Calculating for N = " + N);
            long startTime = System.currentTimeMillis();

            // === Логика из ваших логов (восстановленная) ===
            
            // 1. Количество потоков = количеству ядер
            int threads = Runtime.getRuntime().availableProcessors();
            ExecutorService exec = Executors.newFixedThreadPool(threads);

            // 2. LongAdder для безопасного подсчета суммы шагов
            LongAdder totalSteps = new LongAdder();

            // 3. Расчет количества задач (пакетов)
            int numTasks = (N + BATCH_SIZE - 1) / BATCH_SIZE;
            CountDownLatch latch = new CountDownLatch(numTasks);

            // 4. Разбиение на пакеты
            for (int i = 1; i <= N; i += BATCH_SIZE) {
                final int start = i;
                final int end = Math.min(N, i + BATCH_SIZE - 1);

                exec.submit(() -> {
                    try {
                        long batchSum = 0;
                        for (int j = start; j <= end; j++) {
                            batchSum += calculateCollatzSteps(j);
                        }
                        totalSteps.add(batchSum);
                    } finally {
                        latch.countDown();
                    }
                });
            }

            // Ожидаем завершения всех задач
            try {
                latch.await();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            exec.shutdown();

            // Расчет среднего значения
            double average = (double) totalSteps.sum() / N;
            long duration = System.currentTimeMillis() - startTime;

            // Отправка результата клиенту
            String response = String.format("N: %d, Average steps: %.2f, Time: %d ms", N, average, duration);
            out.println(response);
            System.out.println("Done: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                // ignore
            }
        }
    }

    // Метод вычисления шагов (алгоритм Коллатца)
    private static int calculateCollatzSteps(int n) {
        int steps = 0;
        long val = n; // Используем long, чтобы избежать переполнения при умножении
        while (val > 1) {
            if ((val & 1) == 0) { // Если четное (эквивалент val % 2 == 0)
                val >>= 1;        // Делим на 2
            } else {
                val = 3 * val + 1;
            }
            steps++;
        }
        return steps;
    }
}