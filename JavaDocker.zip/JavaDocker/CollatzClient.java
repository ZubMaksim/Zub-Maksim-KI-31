import java.io.*;
import java.net.*;

public class CollatzClient {
    public static void main(String[] args) {
        try {
            // 1.1. & 1.2. Отримання параметрів із змінних оточення
            String host = System.getenv("SERVER_HOST");
            String portStr = System.getenv("SERVER_PORT");
            String countStr = System.getenv("COLLATZ_COUNT");

            // Перевірка наявності змінних (для безпеки)
            if (host == null || portStr == null || countStr == null) {
                System.err.println("Error: Env vars SERVER_HOST, SERVER_PORT, or COLLATZ_COUNT are missing.");
                return;
            }

            int port = Integer.parseInt(portStr);
            
            System.out.println("Connecting to " + host + ":" + port + " with N=" + countStr);

            // 1.3. Встановлення з'єднання
            try (Socket socket = new Socket(host, port);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                // 1.4. Надсилання числа N
                out.println(countStr);

                // 1.5. Очікування відповіді
                String response = in.readLine();

                // 1.6. Виведення результату
                System.out.println("Average steps for 1.." + countStr + ": " + response);
            }

        } catch (UnknownHostException e) {
            System.err.println("Server not found: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O Error: " + e.getMessage());
        }
    }
}